package com.company;

public class Main {

    public static void main(String[] args) {
        Game snk_n_lad = new Game();
        snk_n_lad.setup();
        snk_n_lad.run();
    }
}
