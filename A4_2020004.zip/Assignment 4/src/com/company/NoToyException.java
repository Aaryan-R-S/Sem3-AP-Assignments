package com.company;

public class NoToyException extends Exception{
    NoToyException(String message){
        super(message);
    }
}
