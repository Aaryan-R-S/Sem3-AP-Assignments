package com.company;

public interface GenericCalculator <T>{
    public T operate(T op1, T op2);
}
