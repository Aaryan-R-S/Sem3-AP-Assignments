package com.company;

public interface Lecture {
    public void view();
}
