package com.company;

public interface User {
    String getName();
    int getID();
    int ret_type();
}
